package com.example.spring_boot_api_jwt_ad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootApiJwtAdApplicationTests {

    @Test
    void contextLoads() {
    }

}
